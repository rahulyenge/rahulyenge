import React from "react";

import classes from './home.module.css';

const Home = (props) => {
    return (
        <>
            <div className={classes.home_page}>
                <h5 className={classes.home_page_heading}>Welcome !!</h5>
            </div>

        </>

    )
}

export default Home
import React, { Component } from "react";

import Home from "../../../component/Home/Home";

class HomePage extends Component {
    render() {
        return (
            <>
                <Home />
            </>
        )
    }
}

export default HomePage